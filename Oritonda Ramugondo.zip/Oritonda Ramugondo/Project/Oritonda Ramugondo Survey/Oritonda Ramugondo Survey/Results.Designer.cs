﻿namespace Oritonda_Ramugondo_Survey
{
    partial class Results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioRating = new System.Windows.Forms.Label();
            this.tvRating = new System.Windows.Forms.Label();
            this.movieRating = new System.Windows.Forms.Label();
            this.eatoutRating = new System.Windows.Forms.Label();
            this.pPapWors = new System.Windows.Forms.Label();
            this.Ppasta = new System.Windows.Forms.Label();
            this.pPizza = new System.Windows.Forms.Label();
            this.minAge = new System.Windows.Forms.Label();
            this.maxAge = new System.Windows.Forms.Label();
            this.AverageAge = new System.Windows.Forms.Label();
            this.totalSurveys = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // radioRating
            // 
            this.radioRating.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.radioRating.AutoSize = true;
            this.radioRating.Location = new System.Drawing.Point(398, 385);
            this.radioRating.Name = "radioRating";
            this.radioRating.Size = new System.Drawing.Size(82, 13);
            this.radioRating.TabIndex = 45;
            this.radioRating.Text = "#average rating";
            // 
            // tvRating
            // 
            this.tvRating.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tvRating.AutoSize = true;
            this.tvRating.Location = new System.Drawing.Point(398, 352);
            this.tvRating.Name = "tvRating";
            this.tvRating.Size = new System.Drawing.Size(82, 13);
            this.tvRating.TabIndex = 44;
            this.tvRating.Text = "#average rating";
            // 
            // movieRating
            // 
            this.movieRating.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.movieRating.AutoSize = true;
            this.movieRating.Location = new System.Drawing.Point(398, 318);
            this.movieRating.Name = "movieRating";
            this.movieRating.Size = new System.Drawing.Size(82, 13);
            this.movieRating.TabIndex = 43;
            this.movieRating.Text = "#average rating";
            // 
            // eatoutRating
            // 
            this.eatoutRating.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.eatoutRating.AutoSize = true;
            this.eatoutRating.Location = new System.Drawing.Point(401, 284);
            this.eatoutRating.Name = "eatoutRating";
            this.eatoutRating.Size = new System.Drawing.Size(94, 13);
            this.eatoutRating.TabIndex = 42;
            this.eatoutRating.Text = "#average of rating";
            // 
            // pPapWors
            // 
            this.pPapWors.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pPapWors.AutoSize = true;
            this.pPapWors.Location = new System.Drawing.Point(398, 230);
            this.pPapWors.Name = "pPapWors";
            this.pPapWors.Size = new System.Drawing.Size(41, 13);
            this.pPapWors.TabIndex = 41;
            this.pPapWors.Text = "label18";
            // 
            // Ppasta
            // 
            this.Ppasta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Ppasta.AutoSize = true;
            this.Ppasta.Location = new System.Drawing.Point(398, 191);
            this.Ppasta.Name = "Ppasta";
            this.Ppasta.Size = new System.Drawing.Size(41, 13);
            this.Ppasta.TabIndex = 40;
            this.Ppasta.Text = "label17";
            // 
            // pPizza
            // 
            this.pPizza.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pPizza.AutoSize = true;
            this.pPizza.Location = new System.Drawing.Point(398, 158);
            this.pPizza.Name = "pPizza";
            this.pPizza.Size = new System.Drawing.Size(41, 13);
            this.pPizza.TabIndex = 39;
            this.pPizza.Text = "label16";
            // 
            // minAge
            // 
            this.minAge.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.minAge.AutoSize = true;
            this.minAge.Location = new System.Drawing.Point(395, 95);
            this.minAge.Name = "minAge";
            this.minAge.Size = new System.Drawing.Size(51, 13);
            this.minAge.TabIndex = 38;
            this.minAge.Text = "#min age";
            // 
            // maxAge
            // 
            this.maxAge.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maxAge.AutoSize = true;
            this.maxAge.Location = new System.Drawing.Point(395, 69);
            this.maxAge.Name = "maxAge";
            this.maxAge.Size = new System.Drawing.Size(54, 13);
            this.maxAge.TabIndex = 37;
            this.maxAge.Text = "#max age";
            // 
            // AverageAge
            // 
            this.AverageAge.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.AverageAge.AutoSize = true;
            this.AverageAge.Location = new System.Drawing.Point(395, 46);
            this.AverageAge.Name = "AverageAge";
            this.AverageAge.Size = new System.Drawing.Size(76, 13);
            this.AverageAge.TabIndex = 36;
            this.AverageAge.Text = "#Average Age";
            // 
            // totalSurveys
            // 
            this.totalSurveys.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.totalSurveys.AutoSize = true;
            this.totalSurveys.Location = new System.Drawing.Point(395, 24);
            this.totalSurveys.Name = "totalSurveys";
            this.totalSurveys.Size = new System.Drawing.Size(52, 13);
            this.totalSurveys.TabIndex = 35;
            this.totalSurveys.Text = "#Surveys";
            // 
            // btnOk
            // 
            this.btnOk.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnOk.Location = new System.Drawing.Point(496, 388);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(200, 50);
            this.btnOk.TabIndex = 34;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(114, 386);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(157, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "People like to listen to the radio:";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(148, 352);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(123, 13);
            this.label10.TabIndex = 32;
            this.label10.Text = "People like to watch TV:";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(129, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 13);
            this.label9.TabIndex = 31;
            this.label9.Text = "People like to watch movies:";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(161, 285);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 13);
            this.label8.TabIndex = 30;
            this.label8.Text = "People like to eat out:";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(69, 230);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(202, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Percentage of people like Pap and Wors:";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(87, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 13);
            this.label6.TabIndex = 28;
            this.label6.Text = "Percentage of people who like Pasta:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(89, 159);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "Percentage of people who like Pizza:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(216, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "Youngest person who participated in survey:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Oldest person who participated in survey:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(200, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "Average age:";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(148, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Total number of surveys:";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(439, 159);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 13);
            this.label12.TabIndex = 46;
            this.label12.Text = "%";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(439, 192);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 13);
            this.label13.TabIndex = 47;
            this.label13.Text = "%";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(439, 230);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 13);
            this.label14.TabIndex = 48;
            this.label14.Text = "%";
            // 
            // Results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.radioRating);
            this.Controls.Add(this.tvRating);
            this.Controls.Add(this.movieRating);
            this.Controls.Add(this.eatoutRating);
            this.Controls.Add(this.pPapWors);
            this.Controls.Add(this.Ppasta);
            this.Controls.Add(this.pPizza);
            this.Controls.Add(this.minAge);
            this.Controls.Add(this.maxAge);
            this.Controls.Add(this.AverageAge);
            this.Controls.Add(this.totalSurveys);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Results";
            this.Text = "Results";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Results_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label radioRating;
        private System.Windows.Forms.Label tvRating;
        private System.Windows.Forms.Label movieRating;
        private System.Windows.Forms.Label eatoutRating;
        private System.Windows.Forms.Label pPapWors;
        private System.Windows.Forms.Label Ppasta;
        private System.Windows.Forms.Label pPizza;
        private System.Windows.Forms.Label minAge;
        private System.Windows.Forms.Label maxAge;
        private System.Windows.Forms.Label AverageAge;
        private System.Windows.Forms.Label totalSurveys;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}